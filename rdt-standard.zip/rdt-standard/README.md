# rdt-standard

[![Build Status](https://travis-ci.org/onaio/rdt-standard.svg?branch=master)](https://travis-ci.org/onaio/rdt-standard) [![Coverage Status](https://coveralls.io/repos/github/onaio/rdt-standard/badge.svg?branch=master)](https://coveralls.io/github/onaio/rdt-standard?branch=master) [![Codacy Badge](https://api.codacy.com/project/badge/Grade/97b0f387f0fa484caffea641f4762fbe)](https://www.codacy.com/app/onaio/rdt-standard?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=onaio/rdt-standard&amp;utm_campaign=Badge_Grade)


Work and document management for RDT standard development
