package io.ona.rdt.contract;

import io.ona.rdt.callback.OnImageSavedCallback;

/**
 * Created by Vincent Karuri on 14/08/2019
 */
public interface CustomRDTCaptureContract {

    interface View extends OnImageSavedCallback {
        String getBaseEntityId();

        boolean isManualCapture();
    }

    interface  Presenter {

    }
}
