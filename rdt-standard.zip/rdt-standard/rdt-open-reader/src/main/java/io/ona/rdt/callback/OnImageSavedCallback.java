package io.ona.rdt.callback;

import io.ona.rdt.domain.CompositeImage;

/**
 * Created by Vincent Karuri on 15/10/2019
 */
public interface OnImageSavedCallback {
    void onImageSaved(CompositeImage compositeImage);
}
