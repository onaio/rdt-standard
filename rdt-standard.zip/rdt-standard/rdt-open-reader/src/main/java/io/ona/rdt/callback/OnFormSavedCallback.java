package io.ona.rdt.callback;

/**
 * Created by Vincent Karuri on 18/06/2019
 */
public interface OnFormSavedCallback {

    void onFormSaved();
}
