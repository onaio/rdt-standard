package io.ona.rdt.contract;

/**
 * Created by Vincent Karuri on 16/08/2019
 */
public interface RDTJsonFormActivityContract {

    interface View {
        void onBackPress();
    }

    interface Presenter {
        void onBackPress();
    }
}
