package io.ona.rdt.utils;

public class Constants {

    public class rdtConfigs{
        public static final String rdt_username = "chaone";
        public static final String rdt_password = "Wcaro123";
    }
}
