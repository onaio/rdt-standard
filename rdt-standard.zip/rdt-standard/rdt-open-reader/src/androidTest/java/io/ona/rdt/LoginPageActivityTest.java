package io.ona.rdt;

import android.app.Activity;
import android.support.annotation.StringRes;
import android.support.test.filters.LargeTest;
import android.view.View;
import android.widget.EditText;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import io.ona.rdt.activity.LoginActivity;
import io.ona.rdt.utils.Order;
import io.ona.rdt.utils.OrderedRunner;
import io.ona.rdt.utils.Utils;

import androidx.test.espresso.assertion.ViewAssertions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.rule.ActivityTestRule;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.clearText;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.typeText;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;

@LargeTest
//@RunWith(AndroidJUnit4.class)
@RunWith(OrderedRunner.class)
public class LoginPageActivityTest {


    @Rule
    public ActivityTestRule<LoginActivity> mActivityTestRule = new ActivityTestRule<>(LoginActivity.class);


    Utils utils = new Utils();

    @Test
    @Order(order = 5)
    public void testSuccessfulLogin() throws InterruptedException {
        onView(withId(R.id.login_user_name_edit_text))
                .perform(typeText("indtester1"), closeSoftKeyboard());
        onView(withId(R.id.login_password_edit_text))
                .perform(typeText("Amani123"), closeSoftKeyboard());
        onView(withId(R.id.login_login_btn))
                .perform(click());
        Thread.sleep(5000);
        //onView(withId(R.id.action_family))
               // .check(matches(isDisplayed()));
        //utils.openDrawer();
        //utils.logOut();
        Thread.sleep(1000);
    }

    @Test
    @Order(order = 1)
    public void testEmptyCredentials() throws InterruptedException {
        onView(withId(R.id.login_user_name_edit_text))
                .perform(clearText());
        onView(withId(R.id.login_password_edit_text))
                .perform(clearText());
        onView(withId(R.id.login_login_btn))
                .perform(click());
        Thread.sleep(5000);
        onView(withText("Please check the credentials."))
                .check(matches(isDisplayed()));

    }

    @Test
    @Order(order = 2)

    public void testEmptyPassword() throws InterruptedException {
        onView(withId(R.id.login_user_name_edit_text))
                .perform(typeText("demo"), closeSoftKeyboard());
        onView(withId(R.id.login_password_edit_text))
                .perform(clearText());
        onView(withId(R.id.login_login_btn))
                .perform(click());
        Thread.sleep(5000);
        onView(withText("Please check the credentials."))
                .check(matches(isDisplayed()));

    }

    @Test
    @Order(order = 3)
    public void testEmptyUsername() throws InterruptedException {
        onView(withId(R.id.login_user_name_edit_text))
                .perform(clearText());
        onView(withId(R.id.login_password_edit_text))
                .perform(typeText("Amani123"), closeSoftKeyboard());
        onView(withId(R.id.login_login_btn))
                .perform(click());
        Thread.sleep(5000);
        onView(withText("Please check the credentials."))
                .check(matches(isDisplayed()));

    }

    @Test
    @Order(order = 6)
    public void testUnauthorizedUserGroup() throws InterruptedException {

        // utils.logIn(Constants.WcaroConfigs.wCaro_username, Constants.WcaroConfigs.wCaro_password);
        //utils.logOut();

        onView(withId(R.id.login_user_name_edit_text))
                .perform(typeText("chatwo"), closeSoftKeyboard());
        onView(withId(R.id.login_password_edit_text))
                .perform(typeText("Wcaro123"), closeSoftKeyboard());
        onView(withId(R.id.login_login_btn))
                .perform(click());
        Thread.sleep(5000);
        onView(withText("Your user group is not allowed to access this device."))
                .check(matches(isDisplayed()));

    }

    @Test
    @Order(order = 4)
    public void testInvalidCredentials() throws InterruptedException {
        onView(withId(R.id.login_user_name_edit_text))
                .perform(typeText("demo"), closeSoftKeyboard());
        onView(withId(R.id.login_password_edit_text))
                .perform(typeText("Amani123"), closeSoftKeyboard());
        onView(withId(R.id.login_login_btn))
                .perform(click());
        Thread.sleep(5000);
        onView(withText("Please check the credentials."))
                .check(matches(isDisplayed()));

    }
/*
    private String getString(@StringRes int resourceId) {
        return mActivityTestRule.getActivity().getString(resourceId);
    }
*/
    private static Matcher<View> withError(final String expected) {
        return new TypeSafeMatcher<View>() {
            @Override
            protected boolean matchesSafely(View item) {
                if (item instanceof EditText) {
                    return ((EditText)item).getError().toString().equals(expected);
                }
                return false;
            }

            @Override
            public void describeTo(Description description) {
                description.appendText("Not found error message" + expected + ", find it!");
            }
        };
    }

}

